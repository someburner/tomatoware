Useful Web Links
================

(links)

See the wiki for more links. (The wiki is also updated more often
than this chapter is.)

Cheetah Links
-------------

(links.cheetah)

Home Page, issue tracker
    - https://github.com/CheetahTemplate3/cheetah3

On-line Documentation
    - http://cheetahtemplate.org/


Third-party Cheetah Stuff
-------------------------

(links.thirdParty)


-  Steve Howell has written a photo viewer using Python.
   http://mountainwebtools.com/PicViewer/install.htm


Webware Links
-------------

(links.webware)

Home Page
    - https://cito.github.io/w4py/

On-line Documentation
    - https://webware.sf.net/Webware/Docs/

SourceForge Project Page
    - https://sf.net/projects/webware/

Mailing List Subscription Page
    - http://lists.sourceforge.net/lists/listinfo/webware-discuss


Python Links
------------

(links.python)

Home Page
    - http://www.python.org/

On-line Documentation
    - http://www.python.org/doc/

Python Cookbook
    - https://code.activestate.com/recipes/langs/python/


Other Useful Links
------------------

(links.other)

Python Database Modules and Open Source Databases
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(links.database)

Python Database Topic Guide
    - http://python.org/topics/database/

PostgreSQL Database
    - http://www.postgresql.org/index.html

MySQL Database
    - http://www.mysql.com/

A comparison of PostgreSQL and MySQL
    - http://phpbuilder.com/columns/tim20001112.php3


Other Template Systems
~~~~~~~~~~~~~~~~~~~~~~

(links.other.templateSystems)

Python Wiki
    - https://wiki.python.org/moin/Templating


Other Internet development frameworks
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

(links.internet)

ZOPE (Z Object Publishing Environment)
    - http://zope.org/

Server Side Java
    - http://jakarta.apache.org/

PHP
    - http://php.net/

IBM Websphere
    - http://www.ibm.com/websphere/

Coldfusion and Spectra
    - http://www.macromedia.com/



