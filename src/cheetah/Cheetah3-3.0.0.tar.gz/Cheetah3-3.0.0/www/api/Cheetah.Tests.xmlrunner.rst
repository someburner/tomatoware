Cheetah.Tests.xmlrunner module
==============================

.. automodule:: Cheetah.Tests.xmlrunner
    :members:
    :undoc-members:
    :show-inheritance:
