Cheetah.Utils.WebInputMixin module
==================================

.. automodule:: Cheetah.Utils.WebInputMixin
    :members:
    :undoc-members:
    :show-inheritance:
