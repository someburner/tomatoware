Cheetah.Tests.Boinker module
============================

.. automodule:: Cheetah.Tests.Boinker
    :members:
    :undoc-members:
    :show-inheritance:
