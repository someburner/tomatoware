Cheetah Recipes
==================

.. toctree::
   :maxdepth: 2

   recipes/inheritance.rst
   recipes/precompiled.rst
   recipes/staticmethod.rst
   recipes/writing_a_recipe.rst
