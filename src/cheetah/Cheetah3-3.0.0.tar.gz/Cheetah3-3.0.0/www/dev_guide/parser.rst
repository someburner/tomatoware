The parser
==========

(parser)

How templates are compiled: a walk through Parser.py's source.
(Also need to look at Lexer.py, but not too closely.)


