Template
========

(template)

This chapter will mainly walk through the {Cheetah.Template}
constructor and not at what point the template is compiled.

(Also need to look at Transaction,py and Servlet.py.)


