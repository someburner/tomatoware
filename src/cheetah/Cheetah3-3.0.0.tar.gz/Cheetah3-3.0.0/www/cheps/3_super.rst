(#3) Exposing of super() and self via Template searchList
=========================================================


:CHEP: 3
:Title: Exposing of super() and self via Template searchList
:Version: 1
:Author: R Tyler Ballance <tyler at slide.com>
:Status: Draft
:Type: Standards Track
:Content-Type: text/x-rst
:Created: 07-Jun-2009

----

Abstract
--------

Specification
-------------

Motivation
----------

Rationale
---------

Backwards Compatibility
-----------------------

Reference Implementation
------------------------

Copyright
---------
This document has been placed in the public domain.
