#include <config.h>
#define FCHMODAT_INLINE _GL_EXTERN_INLINE
#include "openat.h"
