
#include "BatteryMeter.h"

void Battery_getData(double* level, ACPresence* isOnAC) {
   *level = -1;
   *isOnAC = AC_ERROR;
}

